from setuptools import setup

setup(
    name='tbtools',
    version='1.0',
    description='Tools for reading/writing files associated with the TxBLEND model',
    author='Taylor Sansom',
    author_email='taylor.sansom@twdb.texas.gov',
    url='https://github.com/twdb/tbtools'
    )